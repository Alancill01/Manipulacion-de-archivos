file = open('test.txt', 'w')
file.write('Esta línea fue agregada por Python.')
file.close()