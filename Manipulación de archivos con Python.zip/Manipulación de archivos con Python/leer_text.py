file = open('test.txt', 'r')
content = file.read()
print(content)
file.close()